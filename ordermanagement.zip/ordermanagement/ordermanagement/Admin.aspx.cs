﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


namespace ordermanagement
{
    public partial class Admin : System.Web.UI.Page
    {
        Class1 dll = new Class1();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {

                bind();

            }
               
           
        }
        public void bind()
        {
            string s = TextBox1.Text;
            GridView1.DataSource = dll.loadgv("SELECT * FROM tbl_order  ");
            GridView1.DataBind();
        }
        
        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            this.bind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataBind();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DropDownList ddlstatus = (DropDownList)e.Row.FindControl("DropDownList1");
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
           
                string st = (GridView1.Rows[e.RowIndex].FindControl("DropDownList1") as DropDownList).SelectedValue;
                string order_id = GridView1.DataKeys[e.RowIndex].Value.ToString();
                SqlConnection conn = new SqlConnection("Data Source=NACRE;Initial Catalog=ordermanagementsystem;Integrated Security=True");
                conn.Open();
                SqlCommand cmd = new SqlCommand("update tbl_order set status =@status where order_id=@order_id", conn);
                {
                    cmd.Parameters.AddWithValue("@order_id", order_id);
                    cmd.Parameters.AddWithValue("@status", st);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    GridView1.EditIndex = -1;
                    GridView1.DataBind();
                    Response.Write("update successful");
                bind();
                }
            
        }

        
    }
}