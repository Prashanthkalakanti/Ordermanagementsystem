﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ordermanagement;
using System.Data;
using System.Data.SqlClient;

namespace ordermanagement
{
    public partial class User : System.Web.UI.Page
    {
        static bool s;
        Class1 dll = new Class1();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TextBox1.Text = Session["admin"].ToString();

                GridView1.DataSource = dll.loadgv("select * from tbl_product");
                GridView1.DataBind();
            }
        }



        protected void Btnorder_Click(object sender, EventArgs e)
        {
            int[] val2 = new int[3];
            if (!IsPostBack)
            {
                s = false;
            }
            // S = true;
            if (!s)
            {
                string[] val = new string[3];

                val[0] = Session["admin"].ToString();
                val[1] = "placed";
                val[2] = TextBox2.Text;
                dll.ins("InsertOrder", val);
                val2[0] = Convert.ToInt32(lbl_Pid.Text);
                val2[1] = Convert.ToInt32(TextBox3.Text);
                val2[2] = dll.getid("select max(order_id) from tbl_order");
                dll.ins1("InsertItems", val2);
                s = true;
                GridView2.DataSource = dll.loadgv("SELECT * FROM tbl_product P JOIN tbl_items Y ON Y.pid=P.product_id AND Y.oderid=" + val2[2]);
                GridView2.DataBind();
            }
            else
            {
                val2[0] = Convert.ToInt32(lbl_Pid.Text);
                val2[1] = Convert.ToInt32(TextBox3.Text);
                val2[2] = dll.getid("select max(order_id) from tbl_order");
                dll.ins1("InsertItems", val2);
                GridView2.DataSource = dll.loadgv("SELECT * FROM tbl_product P JOIN tbl_items Y ON Y.pid=P.product_id AND Y.oderid=" + val2[2]);
                GridView2.DataBind();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("vieworders.aspx");
        }

        protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            lbl_Pid.Text = GridView1.Rows[e.NewSelectedIndex].Cells[1].Text;
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnview_Click(object sender, EventArgs e)
        {
            string s = TextBox1.Text;
            GridView3.DataSource = dll.loadgv("SELECT *  FROM tbl_order where  user_id= '" + s + "'");
            GridView3.DataBind();
        }

        protected void GridView3_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridView2.DataSource = dll.loadgv("select * from tbl_items where oderid= '" + GridView1.Rows[e.NewSelectedIndex].Cells[1].Text + "'");
            GridView2.DataBind();
        }

        protected void GridView3_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=NACRE;Initial Catalog=ordermanagementsystem;Integrated Security=True");

            int order_id = Convert.ToInt16(GridView3.DataKeys[e.RowIndex].Values["order_id"].ToString());
            conn.Open();
            SqlCommand cmd = new SqlCommand("delete from tbl_order where order_id=@order_id", conn);
            cmd.Parameters.AddWithValue("@order_id", order_id);
            int i = cmd.ExecuteNonQuery();

            string s = TextBox1.Text;
            GridView3.DataSource = dll.loadgv("SELECT *  FROM tbl_order where  user_id= '" + s + "'");
            GridView3.DataBind();
            conn.Close();

        }
        public void bind()
        {
            string s = TextBox1.Text;
            GridView3.DataSource = dll.loadgv("SELECT *  FROM tbl_order where  user_id= '" + s + "'");
            GridView3.DataBind();
        }


        protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView3.EditIndex = e.NewEditIndex;
            this.bind();
        }

        protected void GridView3_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

            GridView3.EditIndex = -1;
            GridView3.DataBind();
        }

        protected void GridView3_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string add= ((TextBox)GridView3.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
            string order_id = GridView3.DataKeys[e.RowIndex].Value.ToString();
            SqlConnection conn = new SqlConnection("Data Source=NACRE;Initial Catalog=ordermanagementsystem;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand("update tbl_order set address =@address where order_id=@order_id", conn);
            {
                cmd.Parameters.AddWithValue("@order_id", order_id);
                cmd.Parameters.AddWithValue("@address", add);

                cmd.ExecuteNonQuery();
                conn.Close();
                GridView3.EditIndex = -1;
                GridView3.DataBind();
                Response.Write("update successful");
                bind();
            }
        }
    }
}