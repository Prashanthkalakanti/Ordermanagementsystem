﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ordermanagement
{
    public partial class loginpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=NACRE;Initial Catalog=ordermanagementsystem;Integrated Security=True");
            
            SqlCommand cmd = new SqlCommand("select role from logindetails where username='" + TextBox1.Text + "'and password='" + TextBox2.Text + "' ", conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {

                if (dr[0].ToString() == "ADMIN")
                {
                    Session["admin"] = TextBox1.Text;
                    Response.Redirect("Admin.aspx");
                }
                else if (dr[0].ToString() == "USER")
                {
                    Session["admin"] = TextBox1.Text;
                    Response.Redirect("User.aspx");
                }
            }
            else
            {

                Response.Write("<h1>invalid user name or password</h1> ");
            }
            conn.Close();
        }
    }
}