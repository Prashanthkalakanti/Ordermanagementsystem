﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace ordermanagement
{
    public class Class1
    {
        SqlConnection con = new SqlConnection("Data Source=NACRE;Initial Catalog=ordermanagementsystem;Integrated Security=True");
        public int ins(string sql,string[] val)
        {
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@buyer_name", val[0]);
            cmd.Parameters.AddWithValue("@order_status", val[1]);
            cmd.Parameters.AddWithValue("@order_address", val[2]);

            int i = cmd.ExecuteNonQuery();
            con.Close();
            return i;
        }
        public int ins1(string sql, int[] val2)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO tbl_items VALUES("+val2[2]+","+val2[0]+","+val2[1]+")", con);
            con.Open();
            //  cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@pid", val2[0]);
            //cmd.Parameters.AddWithValue("@quantity", val2[1]);
            //cmd.Parameters.AddWithValue("@order_id", val2[2]);
            SqlCommand cmd1 = new SqlCommand("UPDATE tbl_product SET quantity=quantity-"+val2[1]+" WHERE product_id=" + val2[0] + "", con);

            int i = cmd.ExecuteNonQuery();
            cmd1.ExecuteNonQuery();
            con.Close();
            return i;
        }
        public DataSet loadgv(String sql)
        {
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public int getid(string sql)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            int id =Convert.ToInt32( cmd.ExecuteScalar());
            con.Close();
            return id;
        }
    }
}